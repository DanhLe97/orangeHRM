package pages;

import java.awt.Button;
import java.util.logging.LogManager;
import com.fasterxml.jackson.databind.JsonNode;
import dataobjects.Employee;
import elements.ButtonElement;
import elements.LabelElement;
import elements.TextBoxElement;
import org.apache.logging.log4j.Logger;

import utils.constants.TestConfigConstant;
import utils.helpers.LocatorHelper;

public class LeavePage extends PageBase {
private JsonNode locator = LocatorHelper.loadLocators(TestConfigConstant.LEAVE_PAGE);
private String dynamicLeaveMenu = locator.get("dynamicLeaveMenu").asText();
private LabelElement txtEmployeeName = new LabelElement(locator.get("txtEmployeeName").asText());
private LabelElement dropdownLeaveType = new LabelElement(locator.get("dropdownLeaveType").asText());


public void selectLeaveMenu(String menuItem) {
	LabelElement lblMenuItem = new LabelElement(locator.get("dynamicLeaveMenu").asText(), menuItem);
	lblMenuItem.waitForElementToBeClickable();
	lblMenuItem.click();
}
public void inputAssignLeave(String a, String b, String c, String d)
{
	txtEmployeeName.waitForElementToBeVisible();
	txtEmployeeName.sendKeys(a);
	dropdownLeaveType.selectItemInDropdown(b);
	
	
}
}
