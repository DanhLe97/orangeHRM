package testcases;

import org.testng.annotations.Test;

import dataobjects.Account;
import dataobjects.Employee;
import pages.DashboardPage;
import pages.LeavePage;
import pages.LoginPage;
import pages.PIM_AddEmployeePage;
import reportConfig.CustomLogger;
import utils.helpers.DataHelper;


public class LeaveManage extends TestBase {
	@Test(dataProvider = "jsonDataProvider", description = "Verify that user can submit leave request")
    public void OHRM_MANAGE_EMPLOYEE_TC006(DataHelper data) {
    	CustomLogger logger = new CustomLogger();
    	Account account = data.getData("valid_account", Account.class);
    	String LeaveMenuItem = data.getStringData("LeaveMenuItem");
    	String AssignLeaveItem = data.getStringData("AssignLeave");
    	String PIMMenuItem = data.getStringData("PIMMenuItem");
    	Employee employee = DataPreparation.generateEmployee();
    	String employeeName = employee.getFirstName() + "" + employee.getLastName();
    	String leaveType = data.getStringData("leaveType");
    	
    	
    	logger.info("Pre-condition: An employee is created");
        LoginPage loginPage = new LoginPage();
        loginPage.login(account);

        DashboardPage dashboardPage = new DashboardPage();
        dashboardPage.selectMenuItem(PIMMenuItem);

        PIM_AddEmployeePage pim_addEmployeePage = new PIM_AddEmployeePage();
        pim_addEmployeePage.clickAddNewEmployee();

        pim_addEmployeePage.enterEmployeeInfo(employee);
        pim_addEmployeePage.toggleCreateLoginDetails();
        pim_addEmployeePage.inputUserLoginDetail(employee);
       

        pim_addEmployeePage.clickBtnSave();
        logger.info("Step #1: Login with valid admin account");
        logger.info("Step #2: Select Leave menu item");
    	pim_addEmployeePage.selectMenuItem(LeaveMenuItem);
    	LeavePage leavePage = new LeavePage();
    	logger.info("Step #3: Select Assign Leave item");
    	leavePage.selectLeaveMenu(AssignLeaveItem);
    	
    	logger.info("Step #4: Enter page assign fields");
    	leavePage.inputAssignLeaveInfo(employeeName);
    	
    }
	
	@Test(dataProvider = "jsonDataProvider", description = "Verify that user can delete Leave type.")
	public void OHRM_LEAVE_TC007 (DataHelper data) {
		CustomLogger logger = new CustomLogger();
		Account account = data.getData("valid_account", Account.class);
		String LeaveMenuItem = data.getStringData("LeaveMenuItem");
		
		
	}
}
