package utils.constants;

public class ConfigConstant {

    public static final String CONFIGURATION_PROPERTIES = "properties/config.properties";
}
